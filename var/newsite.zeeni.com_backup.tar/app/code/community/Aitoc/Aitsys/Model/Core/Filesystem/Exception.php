<?php
/**
 * @copyright  Copyright (c) 2009 AITOC, Inc.
 */
class Aitoc_Aitsys_Model_Core_Filesystem_Exception extends Mage_Core_Exception
{
}