<?php
/**
 * @copyright  Copyright (c) 2009 AITOC, Inc. 
 */
class Aitoc_Aitsys_Helper_License extends Aitoc_Aitsys_Helper_Data
{
    public function uninstallBefore(){}
	public function installBefore(){}
}
